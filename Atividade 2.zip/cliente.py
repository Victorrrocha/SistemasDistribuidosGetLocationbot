import socket
from _thread import *
import threading
import psutil
import time
import argparse

import random
import string

def get_random_string(length):
    # Random string with the combination of lower and upper case
    letters = string.ascii_letters
    result_str = ''.join(random.choice(letters) for i in range(length))
    return result_str

def thread_requisitor(host, port, m):
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    soc.connect((host,port))

    soc.send(m.encode('ascii'))
    data = soc.recv(1024)

    print_lock.acquire()
    print("Reposta do Servidor\n", str(data.decode('ascii')), end="\n")
    print_lock.release()

    soc.close()

parser = argparse.ArgumentParser()
parser.add_argument("-b", "--bytes", type=int, dest="bytes", help="number of bytes to send for thread", default=1024)
parser.add_argument("-r", "--requests", type=int, dest="requests", help="number of requests to send for server", default=50)
                    
args = parser.parse_args()
requests = args.requests
bytes = args.bytes

host = '127.0.0.1'
port = 3000

print_lock = threading.Lock()

for i in range(requests):
    start_new_thread(thread_requisitor, (host, port, get_random_string(bytes),))

time.sleep(15)

# top -b -p 23116 -n 150 -d 0.1 | grep 23116 >> resposta.txt &
